# pip install mysql-connector-python
# pip install matplotlib
# streamlit run main.py

import streamlit as st
import mysql.connector
import pandas as pd
import matplotlib.pyplot as plt

# fontend page setting
st.set_page_config(layout = "wide")

st.markdown(
    "<h1 style = 'text-align:center'>Real Life Accident Data Analysis</h1>",
    unsafe_allow_html=True
)

# database connection
myConnection = mysql.connector.connect(
                    host = "localhost",
                    user = "root",
                    password = "password",
                    database = "accidents101",
                    use_pure = True
)

cursor = myConnection.cursor()

# Side Menu bar

st.sidebar.title("Dashboard Menu")
st.sidebar.markdown("---")

chart = st.sidebar.radio(
    "SELECT ANY ANALYSIS",
    [
        "Type of Vehicles",
        "Accidents By Severity",
        "Accidents by Day",
        "Accidents by Speed limit on Road",
        "Accidents by Weather condition",
        "Accidents by Urban_or_Rural_Area",
        "Age VS Casualties"
    ]
)

if chart == "Type of Vehicles":
    cursor.execute("SELECT vehicle_type FROM vehicle_types")

    df = pd.DataFrame(cursor.fetchall(), columns = ["Vehicle Type"])

    st.dataframe(df)

elif chart == "Accidents By Severity":
    cursor.execute("SELECT Accident_Severity, count(*) FROM accident GROUP BY Accident_Severity")

    df = pd.DataFrame(cursor.fetchall(), columns = ["Severity", "Count"])

    fig, ax = plt.subplots(figsize=(6,4))

    ax.bar(df["Severity"], df["Count"], color = 'red')

    ax.set_title("Accident by Severity")
    ax.set_xlabel("Number of Serverity")
    ax.set_ylabel("Count of Accidents")

    st.pyplot(fig)

elif chart == "Accidents by Day":
    cursor.execute("SELECT Day_of_Week, count(*) FROM accident GROUP BY Day_of_Week ORDER BY Day_of_Week")

    df = pd.DataFrame(cursor.fetchall(), columns = ["Day of Week", "Count"])

    fig, ax = plt.subplots(figsize=(6,4))

    ax.plot(df["Day of Week"], df["Count"], color = 'red')

    ax.set_title("Accidents by Day")
    ax.set_xlabel("Day of Week")
    ax.set_ylabel("Count of Accidents")

    st.pyplot(fig)

elif chart == "Accidents by Speed limit on Road":
    cursor.execute("SELECT Speed_limit, count(*) FROM accident GROUP BY Speed_limit")

    df = pd.DataFrame(cursor.fetchall(), columns = ["Speed_limit", "Count"])

    fig, ax = plt.subplots(figsize=(6,4))

    ax.pie(df["Count"], labels = df["Speed_limit"])

    ax.set_title("Accidents by Speed_limit")
    ax.set_xlabel("Speed_limit")
    ax.set_ylabel("Count of Accidents")

    st.pyplot(fig)

elif chart == "Accidents by Weather condition":
    cursor.execute("SELECT Weather_Conditions, count(*) FROM accident GROUP BY Weather_Conditions")

    df = pd.DataFrame(cursor.fetchall(), columns = ["Weather_Conditions", "Count"])

    fig, ax = plt.subplots(figsize=(6,4))

    ax.barh(df["Weather_Conditions"], df["Count"], color = 'red')

    ax.set_title("Accidents by Weather_Conditions")
    ax.set_xlabel("Count of Accidents")
    ax.set_ylabel("Weather_Conditions")

    st.pyplot(fig)

# Plot the pie chart to show Urban VS Rural
elif chart == "Accidents by Urban_or_Rural_Area":
    cursor.execute("SELECT Urban_or_Rural_Area, count(*) FROM accident GROUP BY Urban_or_Rural_Area")

    df = pd.DataFrame(cursor.fetchall(), columns = ["Urban_or_Rural_Area", "Count"])

    fig, ax = plt.subplots(figsize=(6,4))

    ax.pie(df["Count"], labels = df["Urban_or_Rural_Area"])

    ax.set_title("Accidents by Urban_or_Rural_Area")
    ax.set_xlabel("Urban_or_Rural_Area")
    ax.set_ylabel("Count of Accidents")

    st.pyplot(fig)
# Age VS casualties (using Join) : Age_of_Driver -> vehicles, Number_of_Casualties -> accident
elif chart == "Age VS Casualties":
    cursor.execute("""SELECT v.Age_of_Driver, a.Number_of_Casualties 
                   FROM accident a INNER JOIN vehicles v ON a.Accident_Index = v.Accident_index""")

    df = pd.DataFrame(cursor.fetchall(), columns = ["Age", "Casualties"])

    fig, ax = plt.subplots(figsize=(6,4))

    ax.scatter(df["Age"], df["Casualties"])

    ax.set_title("Accidents by Age VS Casualties")
    ax.set_xlabel("Age")
    ax.set_ylabel("Casualties")

    st.pyplot(fig)
# Show drivers older than Average Age (use the subquery)


# Vehicle Ranking based upon the usage